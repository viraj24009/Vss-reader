# VSS Reader

A native Android PDF-reader starter project built with Kotlin and Jetpack Compose.

## Build APK
1. Install Android Studio (Hedgehog or newer) on a computer.
2. Open this `VSSReader` folder in Android Studio.
3. Let Gradle sync complete. Use JDK 17.
4. Connect an Android phone or start an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Current implementation
- Dark premium glass-inspired home/library interface
- Import PDFs using Android's document picker
- Local library list for the current app session
- PDF first-page rendering using Android PdfRenderer
- Pinch zoom on the rendered page
- Reader header, page counter controls and bookmark toggle UI

## Important current limitation
This is an initial source-code build, not a compiled or device-tested APK. The current reader renders the first page only; page-by-page rendering, persistent library/bookmarks, text search, highlights and annotations are planned next. Do not treat the page arrows as functional multi-page navigation yet.
