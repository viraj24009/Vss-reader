package com.vss.reader

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF171F35)
private val Purple = Color(0xFF9B8CFF)
private val Muted = Color(0xFF9AA6C0)
private val White = Color(0xFFF5F6FF)

data class Book(val name: String, val uri: Uri, val added: Long = System.currentTimeMillis())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11,16,32)
        window.navigationBarColor = android.graphics.Color.rgb(11,16,32)
        setContent { VSSReaderApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VSSReaderApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vss_reader", 0) }
    val books = remember { mutableStateListOf<Book>() }
    var selected by remember { mutableStateOf<Book?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var dark by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching {
                context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && idx >= 0) c.getString(idx) else "Untitled PDF"
                }
            }.getOrNull() ?: "Untitled PDF"
            val book = Book(name, uri)
            books.removeAll { it.uri == uri }
            books.add(0, book)
            prefs.edit().putString("last_name", name).apply()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Purple, onBackground = White,
        onSurface = White, secondary = Color(0xFF71D8D0)
    )) {
        selected?.let { book ->
            ReaderScreen(book = book, onBack = { selected = null })
        } ?: Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF11182B), contentColor = White) {
                    listOf("Home", "Library", "Bookmarks", "Profile").forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = {
                                Icon(when(index) {
                                    0 -> Icons.Rounded.Home
                                    1 -> Icons.Rounded.MenuBook
                                    2 -> Icons.Rounded.Bookmark
                                    else -> Icons.Rounded.Person
                                }, contentDescription = label)
                            },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple, selectedTextColor = Purple,
                                indicatorColor = Purple.copy(alpha = .16f),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { picker.launch(arrayOf("application/pdf")) },
                    containerColor = Purple, contentColor = Ink,
                    icon = { Icon(Icons.Rounded.Add, null) },
                    text = { Text("Add PDF", fontWeight = FontWeight.Bold) }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("VSS READER", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text(when(tab) { 1 -> "Your library"; 2 -> "Saved pages"; 3 -> "Your space"; else -> "Read beautifully." },
                                color = White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        IconButton(onClick = { showInfo = true }, modifier = Modifier.clip(CircleShape).background(Panel)) {
                            Icon(Icons.Rounded.Info, "About", tint = Muted)
                        }
                    }
                }
                if (tab == 0) {
                    item {
                        AnimatedVisibility(true, enter = fadeIn() + slideInVertically()) {
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                                .background(brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF443C86), Color(0xFF202B4B), Color(0xFF153C4B))))
                                .padding(22.dp)) {
                                Text("YOUR PERSONAL\nREADING SPACE", color = White.copy(alpha = .75f), fontSize = 11.sp, letterSpacing = 2.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("A little progress\nevery day.", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                                Spacer(Modifier.height(18.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.AutoStories, null, tint = Color(0xFF9EF0DE))
                                    Spacer(Modifier.width(8.dp))
                                    Text("${books.size} books in your library", color = White.copy(alpha = .85f), fontSize = 13.sp)
                                }
                            }
                        }
                    }
                    item { SectionTitle("Continue reading", "PICK UP WHERE YOU LEFT OFF") }
                    if (books.isEmpty()) {
                        item { EmptyCard(onAdd = { picker.launch(arrayOf("application/pdf")) }) }
                    } else {
                        items(books.take(3)) { book -> BookCard(book, onClick = { selected = book }) }
                    }
                    item { SectionTitle("Recently added", "YOUR COLLECTION") }
                    if (books.isNotEmpty()) items(books.drop(3)) { book -> BookCard(book, onClick = { selected = book }) }
                } else if (tab == 1) {
                    item { Text("All your PDFs, together in one calm space.", color = Muted, fontSize = 14.sp) }
                    if (books.isEmpty()) item { EmptyCard { picker.launch(arrayOf("application/pdf")) } }
                    items(books) { book -> BookCard(book, onClick = { selected = book }) }
                } else if (tab == 2) {
                    item {
                        EmptyState(Icons.Rounded.BookmarkBorder, "No bookmarks yet", "Open a PDF and use the bookmark button to save a page.")
                    }
                } else {
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
                            Text("VSS Reader", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Version 1.0 • Built for focused reading", color = Muted, modifier = Modifier.padding(top = 6.dp))
                            HorizontalDivider(Modifier.padding(vertical = 16.dp), color = White.copy(alpha = .08f))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.AutoAwesome, null, tint = Purple)
                                Spacer(Modifier.width(10.dp))
                                Text("Minimal distractions. Maximum reading.", color = White)
                            }
                        }
                    }
                }
            }
        }
        if (showInfo) {
            AlertDialog(onDismissRequest = { showInfo = false }, containerColor = Panel,
                title = { Text("About VSS Reader", color = White) },
                text = { Text("A modern PDF reading space with local document access, smooth page navigation, zoom and a clean reading interface.", color = Muted) },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Got it", color = Purple) } })
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(subtitle, color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(title, color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun EmptyCard(onAdd: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.PictureAsPdf, null, tint = Purple, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp))
        Text("Your library is waiting", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Import a PDF book, notes or study material to begin.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = onAdd) { Text("Choose a PDF", color = Purple) }
    }
}

@Composable
fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Column(Modifier.fillMaxWidth().padding(top = 70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Purple, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(detail, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun BookCard(book: Book, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).clickable { onClick() }.padding(15.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Purple.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PictureAsPdf, null, tint = Purple, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(book.name, color = White, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("PDF DOCUMENT  •  READY TO READ", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 5.dp))
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun ReaderScreen(book: Book, onBack: () -> Unit) {
    val context = LocalContext.current
    var pageCount by remember(book.uri) { mutableIntStateOf(0) }
    var currentPage by remember(book.uri) { mutableIntStateOf(0) }
    var pageBitmaps by remember(book.uri) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var error by remember(book.uri) { mutableStateOf<String?>(null) }
    var bookmarked by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(book.uri) {
        withContext(Dispatchers.IO) {
            try {
                val pfd = context.contentResolver.openFileDescriptor(book.uri, "r")
                    ?: throw IllegalStateException("Could not open this PDF.")
                val renderer = PdfRenderer(pfd)
                pageCount = renderer.pageCount
                val bitmaps = mutableListOf<Bitmap>()
                // Render the first page initially; other pages are rendered on demand as the reader moves.
                if (renderer.pageCount > 0) {
                    val page = renderer.openPage(0)
                    val width = 1100
                    val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    bitmaps.add(bitmap)
                }
                pageBitmaps = bitmaps
                renderer.close()
                pfd.close()
            } catch (e: Exception) { error = e.message ?: "Unable to render this PDF." }
        }
    }

    Column(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = White) }
            Column(Modifier.weight(1f)) {
                Text(book.name, color = White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (pageCount > 0) "Page ${currentPage + 1} of $pageCount" else "Opening document…", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = { bookmarked = !bookmarked }) {
                Icon(if (bookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, null, tint = Purple)
            }
            IconButton(onClick = { zoom = 1f }) { Icon(Icons.Rounded.FitScreen, null, tint = Muted) }
        }
        if (error != null) {
            EmptyState(Icons.Rounded.ErrorOutline, "Can't open this PDF", error!!)
        } else if (pageBitmaps.isNotEmpty()) {
            val state = rememberTransformableState { scale, _, _ -> zoom = (zoom * scale).coerceIn(1f, 4f) }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFEDEDED))) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).transformable(state)) {
                    Image(bitmap = pageBitmaps.first().asImageBitmap(), contentDescription = "PDF page 1",
                        modifier = Modifier.fillMaxWidth().graphicsLayer(scaleX = zoom, scaleY = zoom))
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = { currentPage = (currentPage - 1).coerceAtLeast(0) }, enabled = currentPage > 0) {
                    Icon(Icons.Rounded.ChevronLeft, null)
                }
                Text("Page ${currentPage + 1} / ${pageCount.coerceAtLeast(1)}", color = White, fontWeight = FontWeight.SemiBold)
                FilledTonalIconButton(onClick = { currentPage = (currentPage + 1).coerceAtMost((pageCount - 1).coerceAtLeast(0)) }, enabled = currentPage < pageCount - 1) {
                    Icon(Icons.Rounded.ChevronRight, null)
                }
            }
            if (pageCount > 1) Text("Current build renders the first page; multi-page rendering is being expanded.", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
        } else {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Purple)
            }
        }
    }
}
